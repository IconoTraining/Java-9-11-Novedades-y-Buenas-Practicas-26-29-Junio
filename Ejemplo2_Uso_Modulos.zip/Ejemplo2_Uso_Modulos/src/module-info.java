module com.viewnext.ejemplo2 {
	
	// Para poder usar el modulo de otro proyecto,
	// es necesario agregarlo como dependencia en Build path
	
	// requires nombre_modulo
	requires com.viewnext.ejemplo1;
	
}
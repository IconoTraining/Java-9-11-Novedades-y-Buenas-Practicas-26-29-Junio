package com.viewnext;

import java.util.Optional;

import com.viewnext.models.Producto;
import com.viewnext.persistence.ProductosDAO;

public class AppMain {

	public static void main(String[] args) {
		
		
		ProductosDAO dao = new ProductosDAO();
		
		dao.consultarTodos().forEach(System.out::println);
		
		// Buscar un producto que existe
		System.out.println("Encontrado: " + dao.buscarProducto(3).get() );
		
		
		// Buscar un producto que NO EXISTE
		// java.util.NoSuchElementException: No value present
		// System.out.println("Encontrado: " + dao.buscarProducto(333333).get() );
		
		// Primera forma de solucion
		System.out.println("Encontrado: " + dao.buscarProducto(333333).orElse(new Producto()) );
	
		
		// Segunda forma
		Optional<Producto> opProdOptional = dao.buscarProducto(33333);
		if (opProdOptional.isPresent()) {
			System.out.println(opProdOptional.get());
		} else {
			System.out.println("Ese producto no existe");
		}

	}

}

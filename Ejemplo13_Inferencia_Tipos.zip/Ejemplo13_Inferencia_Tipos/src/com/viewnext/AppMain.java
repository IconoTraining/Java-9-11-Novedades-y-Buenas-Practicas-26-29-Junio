package com.viewnext;

import java.util.ArrayList;
import java.util.Arrays;

public class AppMain {
	
	// En las propiedades, o variables globales no funciona
	//var propiedad = 100;

	public static void main(String[] args) {
		
		// Solo funciona en variables locales
		var prueba = 200;
		
		// No se puede aplicar a variables sin inicializar o nulas
		//var sin;
		//var nula = null;
		
		// Cuidado con los arrays
		//var numeros = {1,2,3,4,5};   // Error
		var numeros = new int[] {1,2,3,4,5};
		
		// Colecciones
		var lista = new ArrayList<Integer>(Arrays.asList(1,2,3,4));  // lista de enteros
		var lista2 = new ArrayList<>(Arrays.asList(1,2,3,4));  // lista de enteros
		var lista3 = new ArrayList<Integer>();   // lista de enteros
		var lista4 = new ArrayList<>();  // lista de objects
		
		
		// Crear un bucle para mostrar los numeros del 1 al 10 con inferencia de tipos
		for(var num=1; num <= 10; num++) {
			System.out.println(num);
		}
		
		
		// Crear un array de nombres y recorrerlo con inferencia de tipos
		var nombres = new String[] {"Juan", "Maria", "Pedro", "Luis", "Sara"};
		for (var item : nombres) {
			System.out.println(item);
		}
		
		
		// Ejercicio vais a crear los metodos lambda (sumar, restar, multiplicar, dividir) 
		// utilizando inferencia de tipos
		ItfzCalculadora suma = (var n1, var n2) -> n1 + n2;
		System.out.println("7 + 3 = " + suma.operacion(7, 3));
		
		ItfzCalculadora resta = (n1, n2) -> n1 - n2;
		System.out.println("7 - 3 = " + resta.operacion(7, 3));
		
		ItfzCalculadora multiplicacion = (var n1, var n2) -> n1 * n2;
		System.out.println("7 * 3 = " + multiplicacion.operacion(7, 3));
		
		ItfzCalculadora division = (n1, n2) -> n1 / n2;
		System.out.println("7 / 3 = " + division.operacion(7, 3));
		
		// Tampoco funciona si intento guardar el valor de invocar a un metodo sin retorno
		//var respuesta = new AppMain().saludo();

	}
	
	public  void saludo() {
		System.out.println("Holaaaaa");
	}

}

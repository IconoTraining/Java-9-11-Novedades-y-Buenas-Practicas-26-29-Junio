package com.viewnext.interfaz;

public interface ItfzCalculadora {
	
	double sumar(double n1, double n2);
	double restar(double n1, double n2);
	double multiplicar(double n1, double n2);
	double dividir(double n1, double n2);

}

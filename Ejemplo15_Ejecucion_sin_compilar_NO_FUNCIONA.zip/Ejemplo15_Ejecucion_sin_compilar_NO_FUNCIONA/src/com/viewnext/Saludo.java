package com.viewnext;

public class Saludo {
	
	public String saludar(String nombre) {
		return "Hola " + nombre;
	}

}

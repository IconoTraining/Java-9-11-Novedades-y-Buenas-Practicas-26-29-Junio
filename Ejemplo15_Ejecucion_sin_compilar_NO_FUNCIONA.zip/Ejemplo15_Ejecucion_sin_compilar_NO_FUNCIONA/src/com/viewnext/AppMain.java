package com.viewnext;

public class AppMain {

	public static void main(String[] args) {
		// java /Users/anaisabelvegascaceres/Desktop/Novedades9_11_ViewNext_26_Junio/Ejemplo15_Ejecucion_sin_compilar_NO_FUNCIONA/src/com/viewnext/AppMain.java

		Saludo saludo = new Saludo();
		System.out.println(saludo.saludar("Anabel"));
	}

}

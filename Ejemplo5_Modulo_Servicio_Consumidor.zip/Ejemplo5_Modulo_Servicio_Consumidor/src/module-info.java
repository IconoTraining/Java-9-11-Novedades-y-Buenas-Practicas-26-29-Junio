module com.viewnext.ejemplo5 {
	
	// Necesito el modulo donde esta declarada la interface
	requires com.viewnext.ejemplo3;
	
	// Necesito indicar cual es la interface a utilizar
	uses com.viewnext.interfaz.ItfzSaludo;
}
package com.viewnext;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class AppMain {

	public static void main(String[] args) throws IOException {
		
		// Formas de obtener la ruta del fichero
		Path path = Paths.get("/Users/anaisabelvegascaceres/formula_one.csv");
		Path path2 = Path.of("/Users/anaisabelvegascaceres/formula_one.csv");
		
		// Nombre del fichero
		System.out.println(path.getFileName());
		
		// Ruta absoluta del fichero
		System.out.println(path.toAbsolutePath());
		
		// Numero de elementos del path sin incluir la raiz
		System.out.println(path.getNameCount());
		

		Path fichero = Paths.get("/Users/anaisabelvegascaceres/Desktop/prueba.txt");
		
		// Borrar el fihero si existe
		Files.deleteIfExists(fichero);
		
		// Crear nuevo fichero
		Files.createFile(fichero);
		
		// Copiar el fichero
		Path fichero2 = Paths.get("/Users/anaisabelvegascaceres/Desktop/prueba2.txt");
		Files.deleteIfExists(fichero2);
		Files.copy(fichero, fichero2);
		
		// Borrar el fichero original
		Files.delete(fichero);
		
		// Mover fichero
		Path nuevaUbicacion = Path.of("/Users/anaisabelvegascaceres/Documents/prueba2.txt");
		Files.move(fichero2, nuevaUbicacion);
		
		// Crear carpetas
		Path nuevaCarpeta = Path.of("/Users/anaisabelvegascaceres/Documents/Pruebas_ViewNext");
		Files.createDirectory(nuevaCarpeta);
		
		
	}

}

package com.viewnext;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.json.JSONArray;
import org.json.JSONObject;

public class AppMain {

	public static void main(String[] args) throws Exception {
		
		String url = "https://jsonplaceholder.typicode.com/users";
		
		// Preparar la peticion
		URI uri = new URI(url);
		HttpRequest request = HttpRequest.newBuilder(uri).GET().build();
		
		
		// Crear el cliente
		HttpClient cliente = HttpClient.newHttpClient();
		
		
		// Enviar la peticion
		HttpResponse<String> respuesta = cliente.send(request, HttpResponse.BodyHandlers.ofString());
		
	
		// Convertir el string en un array de objectos JSON
		JSONArray jsonArray = new JSONArray(respuesta.body());
		
		// Recorrer el array y por cada item genero un objeto JSON
		for (Object obj : jsonArray) {
			JSONObject jsonObject = new JSONObject(obj.toString());
			
			// Mostrar nombre y apellidos del usuario
			System.out.println(jsonObject.get("username") + " " + 
					jsonObject.get("name"));
		}
		
		

	}

}

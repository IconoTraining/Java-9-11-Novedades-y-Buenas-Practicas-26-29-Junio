module com.viewnext.ejercicio6 {
	
	requires java.net.http;
	requires org.json;
	
}
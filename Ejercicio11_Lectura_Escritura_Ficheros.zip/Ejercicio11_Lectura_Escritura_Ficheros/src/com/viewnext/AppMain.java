package com.viewnext;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AppMain {

	public static void main(String[] args) {
		
		Path fileInput = Paths.get("entrada.txt");
		Path fileOutput = Paths.get("salida.txt");
		
		List<String> lineas = new ArrayList<String>();
		
		try {
			lineas = Files.readAllLines(fileInput);
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		for (String linea : lineas) {
			try {
				Files.writeString(fileOutput, linea + "\n", StandardOpenOption.APPEND);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}

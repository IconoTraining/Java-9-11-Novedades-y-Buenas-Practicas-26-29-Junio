module com.viewnext.ejercicio5 {
	
	requires com.viewnext.ejercicio3;
	uses com.viewnext.interfaz.ItfzCalculadora;
	
}


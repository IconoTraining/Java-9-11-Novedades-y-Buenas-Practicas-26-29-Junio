package com.viewnext;

import com.viewnext.business.ItfzMetodos;
import com.viewnext.business.Metodos;

public class AppMain {

	public static void main(String[] args) {
		
		// Los recursos estaticos no necesitan instancia
		ItfzMetodos.estatico();
		
		
		// Los metodos default si que necesitan instancia al ser dinamicos
		Metodos metodos = new Metodos();
		metodos.defecto();
		
		
		System.out.println(metodos.procesarTexto("Hola, Pepito Perez"));

	}

}

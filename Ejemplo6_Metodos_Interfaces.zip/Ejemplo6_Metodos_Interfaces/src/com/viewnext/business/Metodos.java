package com.viewnext.business;

public class Metodos implements ItfzMetodos{


	// Los metodos default se pueden sobreescribir
	@Override
	public void defecto() {
		System.out.println("Metodo default sobreescrito");
	}

	
	
}

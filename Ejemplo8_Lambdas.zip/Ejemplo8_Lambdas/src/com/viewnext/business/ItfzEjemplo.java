package com.viewnext.business;


// Es una interface funcional porque solo tiene un metodo abstracto

@FunctionalInterface
public interface ItfzEjemplo {
	
	void metodo(String nombre);

}

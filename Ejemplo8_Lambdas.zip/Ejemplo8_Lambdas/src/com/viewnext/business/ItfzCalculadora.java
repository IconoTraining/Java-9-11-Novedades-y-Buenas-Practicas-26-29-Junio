package com.viewnext.business;

public interface ItfzCalculadora {
	
	double operacion(double n1, double n2);

}

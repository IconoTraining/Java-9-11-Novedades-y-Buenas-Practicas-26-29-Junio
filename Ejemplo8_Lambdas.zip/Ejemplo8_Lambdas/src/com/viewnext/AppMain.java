package com.viewnext;

import com.viewnext.business.ItfzCalculadora;
import com.viewnext.business.ItfzEjemplo;

public class AppMain {

	public static void main(String[] args) {
		
		ItfzEjemplo lambda1 = (String nombre) -> System.out.println("Hola " + nombre);
		lambda1.metodo("Anabel");
		
		ItfzEjemplo lambda2 = nombre -> System.out.println(nombre.toUpperCase());
		lambda2.metodo("Pepito");
		
		
		// ItfzCalculadora
		// 4 implementaciones con lambda (suma, resta, multiplicacion y division)
		ItfzCalculadora suma = (double n1, double n2) -> n1 + n2;
		System.out.println("7 + 3 = " + suma.operacion(7, 3));
		
		ItfzCalculadora resta = (n1, n2) -> n1 - n2;
		System.out.println("7 - 3 = " + resta.operacion(7, 3));
		
		ItfzCalculadora multiplicacion = (n1, n2) -> {
			return n1 * n2;
		};
		System.out.println("7 * 3 = " + multiplicacion.operacion(7, 3));

		ItfzCalculadora division = (double n1, double n2) -> {
			return n1 / n2;
		};
		System.out.println("7 / 3 = " + division.operacion(7, 3));
	}

}

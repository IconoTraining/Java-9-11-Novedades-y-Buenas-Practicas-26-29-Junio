package com.viewnext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AppMain {

	public static void main(String[] args) {
		
		List<String> nombres = new ArrayList<>(); 
		nombres.add("Juan");
		nombres.add("Maria");
		nombres.add("Pedro");
		nombres.add(null);
		
		nombres.remove(0);
		System.out.println(nombres);
		
		// Java 9 permite crear listas inmutables
		// como las tuplas en Python
		List<String> nombres2 = List.of("Juan", "Maria", "Pedro");
		
		// Las colecciones inmutables no aceptan valores nulos
		// List<String> nombres2 = List.of("Juan", "Maria", "Pedro", null);
		
		// UnsupportedOperationException
		// nombres2.add("Pepito");
		// nombres2.remove(0);
		System.out.println(nombres2);
		
		// Las colecciones inmutables se utilizan para valores que no cambian
		List<String> dias = List.of("Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo");
		
		
		Set<Integer> numeros = new HashSet<>();
		numeros.add(8);
		numeros.add(new Integer(5));
		numeros.add( (int) 9.5);
		numeros.add(Integer.parseInt("23"));
		numeros.add(8);
		
		System.out.println(numeros);
		
		Set<String> estados = Set.of("Creada", "Asignada", "En curso", "Resuelta");
		// UnsupportedOperationException
		//estados.add("otro");
		System.out.println(estados);
		
		
		Map<String, Double> alumnos = new HashMap<>();
		alumnos.put("Jorge", 9.8);
		alumnos.put("Laura", 7.2);
		alumnos.put("Alex", 4.1);
		
		alumnos.put("Alex", 5.0);
		System.out.println(alumnos);
		
		
		// En Java 9 tambien podemos tener mapas inmutables
		Map<String, Character> diasSemana = Map.of(
				"Lunes", 'L', "Martes", 'M', "Miercoles", 'X', "Jueves", 'J',
				"Viernes", 'V', "Sabado", 'S', "Domingo", 'D');
		
		System.out.println(diasSemana.keySet());  // Solo los dias de la semana
		System.out.println(diasSemana.values());  // Solo la letra de los dias de la semana
		System.out.println(diasSemana.entrySet());  // Elementos key=value
	}

}











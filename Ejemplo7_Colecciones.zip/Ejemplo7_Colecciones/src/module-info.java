module com.viewnext.ejemplo7 {
}
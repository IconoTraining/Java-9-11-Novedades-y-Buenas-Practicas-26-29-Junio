module com.viewnext.ejemplo20 {
	
	requires java.desktop;
	
}
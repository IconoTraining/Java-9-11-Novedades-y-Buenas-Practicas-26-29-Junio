module com.viewnext.ejemplo4 {
	
	// Necesito el modulo donde se declara la interface
	requires com.viewnext.ejemplo3;
	
	// proporcionamos una clase que implementa la interface
	provides com.viewnext.interfaz.ItfzSaludo with com.viewnext.business.Saludo;
	
}